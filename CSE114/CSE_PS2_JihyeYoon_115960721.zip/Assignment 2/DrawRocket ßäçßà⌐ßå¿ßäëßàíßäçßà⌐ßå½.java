//JihyeYoon_115960721_jihye.yoon@stonybrook.edu

public class DrawRocket {
    public static void main(String[] args) {

//        printLines(5);
//        printRightHalf(5);
//        printTop1(5);
      printTop2(6);
//        printBodyLine(5);
      printBody(12,6);
      printFins(12);

    }

    public static void printLines(int numberOfLines) {

        for (int i = 0; i < numberOfLines; i++) {

            System.out.println("1");
        }

    }

    public static void printRightHalf(int numberOfLines) {

        for (int i = 0; i < numberOfLines; i++) {
            for (int j = 0; j < i + 1; j++) {

                System.out.print("1");
            }
            System.out.println();
        }
    }

    public static void printTop1(int numberOfLines) {
        for (int i = 0; i < numberOfLines; i++) {
            for (int j = 0; j < i + 1; j++) {

                System.out.print("2");

            }
            for (int j = 0; j < i + 1; j++) {
                System.out.print("1");
            }
            System.out.println();
        }
    }

    public static void printTop2(int numberOfLines) {
        for (int i = 0; i < numberOfLines; i++) {
            for (int j = 4; j > i - 1; j--) {

                System.out.print(" ");
            }
            for (int h = 0; h < i + 1; h++) {
                System.out.print("2");
            }
            for (int k = 0; k < i + 1; k++) {
                System.out.print("1");
            }
            System.out.println();
        }

    }

    public static void printBodyLine(int lineWidth) {
        for (int i = 0; i < lineWidth; i++) {
            System.out.print("2");
        }
        for (int j = 0; j < lineWidth; j++) {
            System.out.print("1");
        }
        System.out.println();
    }

    public static void printBody(int lineWidth, int numberOfLines) {
        for (int i = 0; i < numberOfLines; i++) {
            for (int j = 0; j < lineWidth / 2; j++) {

                System.out.print("2");

            }
            for (int h = 0; h < lineWidth / 2 - 1; h++) {

                System.out.print("1");
            }
            System.out.println("1");
        }
    }

    public static void printFins(int lineWidth) {
        for (int i = 0; i < 2; i++) {
            System.out.print(" ");
            for (int j = 1; j < lineWidth / 2; j++) {
                System.out.print("2");
            }
            for (int h = 1; h < lineWidth / 2 - 1; h++) {
                System.out.print("1");
            }
            System.out.println("1");
        }
        for (int j = 0; j < lineWidth/2; j++) {
            System.out.print("2");
        }
        for (int h = 1; h < lineWidth / 2 ; h++) {
            System.out.print("1");
        }
        System.out.println("1");
        System.out.print("22");
        for (int j = 1; j < lineWidth / 2 - 2; j++) {
            System.out.print(" ");
        }
        System.out.print("21");
        for(int j = 1; j < lineWidth / 2 - 2; j++) {
            System.out.print(" ");
        }
            System.out.println("11");
        for (int i =0; i < 2; i++) {
            System.out.print("2");
            for (int j = 0; j < lineWidth - 2; j++) {
                System.out.print(" ");
            }
            System.out.println("1");
        }

    }

}