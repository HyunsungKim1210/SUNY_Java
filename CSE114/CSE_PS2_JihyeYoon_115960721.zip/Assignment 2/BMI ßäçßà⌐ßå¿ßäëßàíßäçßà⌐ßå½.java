//JihyeYoon_115960721_jihye.yoon@stonybrook.edu

import java.util.Scanner;

    public class BMI {

        public static void main(String[] args) {
            Scanner console = new Scanner(System.in);

            System.out.print("Units? (e/m): ");
            String character = console.next();

            char unit = character.charAt(0);
            double height;
            double weight;

            if (unit == 'e') {
                System.out.print("Weight (lbs): ");
                weight = console.nextDouble();
                System.out.print("Height (in): ");
                height = console.nextDouble();
                System.out.printf("Your BMI is: %.1f", bmiCalc(weight, height, unit));
            } else if (unit == 'm') {
                System.out.print("Weight (kg): ");
                weight = console.nextDouble();
                System.out.print("Height (meters): ");
                height = console.nextDouble();
                System.out.printf("Your BMI is: %.1f", bmiCalc(weight, height, unit));
            } else {
                System.out.println("Put e or m");
            }
            console.close();
        }

        public static double bmiCalc(double weight, double height, char system){
            if (system == 'e') {
                return (weight/(Math.pow(height, 2))) * 703;
            } else {
                return weight / Math.pow(height, 2);
            }
        }
    }

