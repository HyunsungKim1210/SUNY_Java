//JihyeYoon_115960721_jihye.yoon@stonybrook.edu

import java.util.Scanner;

public class Printer {
    public static void main(String[] args) {
        Scanner console = new Scanner (System.in);

        System.out.print("Enter print job info (A4/A5/Letter/Legal) (Color/Grayscale) (count) Ex: A4 Color 20: ");

        String paperSize = console.next();
        String colorType = console.next();
        int count = console.nextInt();

        int totalCost = computerPrintJob(paperSize, colorType, count);

        System.out.println("Print job cost: " + totalCost + " KRW");

        console.close();

    }
    public static int computerPrintJob (String paperSize, String colorType, int count) {

        int perSheet = 0;
        if (paperSize.equals("A4")) {
            perSheet += 40;
        } else if (paperSize.equals("A5")) {
            perSheet += 20;
        } else if (paperSize.equals("Letter")) {
            perSheet += 55;
        } else if (paperSize.equals("Legal")) {
            perSheet += 60;
        }

        if (colorType.equals("Grayscale")) {
            perSheet += 5;
        } else if (colorType.equals("Color")) {
            perSheet += 35;
        }

        if ((perSheet * count) % 10 != 0) {
            return perSheet * count + 5;
        }
        return perSheet * count;

    }

}
