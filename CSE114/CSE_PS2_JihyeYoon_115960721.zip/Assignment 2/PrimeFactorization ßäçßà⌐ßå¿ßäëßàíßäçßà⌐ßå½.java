//JihyeYoon_115960721_jihye.yoon@stonybrook.edu

import java.util.Scanner;

public class PrimeFactorization {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        System.out.print("Enter integers: ");

        int num = console.nextInt();
        int space = 1;
        int value = 0;

        while (num > 0) {
            value++;
            space *= num;
            num = console.nextInt();
        }
        if (value == 0) {
            System.out.println("Invalid Input");
        } else {
            System.out.println("Product: " + space);
            determinePrimeFactorization (space);
        } console.close();
    }

    public static void determinePrimeFactorization (int space) {
        String prime = "";
        double scale = Math.sqrt (space);
        boolean sign = false;

        for (int i = 2; i <= scale; i++) {
            int count = 0;
            while (space % i == 0) {
                count ++;
                space /= i;
            }
            if (count != 0) {
                if (i != 2){
                    prime += " * ";
                }
                sign = true;
                prime += i + "^" + count + "";
            }
        }
        if (sign == false) {
            prime += space + "^1";
        }
        System.out.println("Prime factorization: " + prime);
    }
}

