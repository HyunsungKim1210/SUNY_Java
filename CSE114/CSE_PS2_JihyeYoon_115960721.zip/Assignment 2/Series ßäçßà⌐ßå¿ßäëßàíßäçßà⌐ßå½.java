//JihyeYoon_115960721_jihye.yoon@stonybrook.edu
public class Series {
    public static void main(String[] args) {
        System.out.printf("series(0.5,1):    %.3f \n",series(0.5,1));
        System.out.printf("series(0.25,2):    %.3f \n",series(0.25,2));
        System.out.printf("series(0.25,8):    %.3f \n",series(0.25,8));
        System.out.printf("series(0.75,13):    %.3f \n",series(0.75,13));
        System.out.printf("series(0.85,33):    %.3f \n",series(0.85,33));
    }

    public static double series (double x, int n) {
        if (n == 1){
            return 1;
        } else
            return Math.pow(-1,(n-1)) * n * Math.pow(x,n) + series (x,n-1);

    }

}
