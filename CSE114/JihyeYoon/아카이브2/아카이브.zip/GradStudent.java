public class GradStudent extends Student {
        public GradStudent(String name, String address, String phoneNumber, String emailAddress,
                           String classYear, String major) {
            super(name, address, phoneNumber, emailAddress, classYear, major);
        }
    }
