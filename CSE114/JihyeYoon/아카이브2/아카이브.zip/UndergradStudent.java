public class UndergradStudent extends Student {
    public UndergradStudent(String name, String address, String phoneNumber, String emailAddress,
                       String classYear, String major) {
        super(name, address, phoneNumber, emailAddress, classYear, major);
    }
}
