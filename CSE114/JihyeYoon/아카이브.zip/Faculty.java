public class Faculty {
}
